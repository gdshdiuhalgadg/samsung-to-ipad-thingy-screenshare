#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"
ROOT="$PWD"
GRADLE_VERSION="8.10.2"
GRADLE_ZIP="$ROOT/.buildtools/gradle-${GRADLE_VERSION}-bin.zip"
GRADLE_HOME="$ROOT/.buildtools/gradle-${GRADLE_VERSION}"

say_err() { printf '\nERROR: %s\n\n' "$1" >&2; }

# Locate Android SDK installed by Android Studio.
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [ -z "$SDK" ]; then
  for CANDIDATE in "$HOME/Library/Android/sdk" "$HOME/Android/Sdk"; do
    if [ -d "$CANDIDATE" ]; then SDK="$CANDIDATE"; break; fi
  done
fi
if [ -z "$SDK" ] || [ ! -d "$SDK" ]; then
  say_err "Android SDK not found. Open Android Studio > Settings > Android SDK and install Android SDK Platform 35, then run this file again."
  read -r -p "Press Enter to close..." _ || true
  exit 1
fi
export ANDROID_SDK_ROOT="$SDK"
export ANDROID_HOME="$SDK"

if [ ! -f "$SDK/platforms/android-35/android.jar" ]; then
  say_err "Android SDK Platform 35 is not installed. In Android Studio: Settings > Android SDK > check Android 15 / API 35 > Apply."
  read -r -p "Press Enter to close..." _ || true
  exit 1
fi

# Prefer Android Studio's bundled Java runtime.
for JDK in \
  "/Applications/Android Studio.app/Contents/jbr/Contents/Home" \
  "/Applications/Android Studio.app/Contents/jre/Contents/Home"; do
  if [ -x "$JDK/bin/java" ]; then export JAVA_HOME="$JDK"; break; fi
done

if ! command -v java >/dev/null 2>&1 && [ -z "${JAVA_HOME:-}" ]; then
  say_err "Java was not found. Install/open Android Studio first."
  read -r -p "Press Enter to close..." _ || true
  exit 1
fi

mkdir -p "$ROOT/.buildtools"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  echo "Downloading Gradle ${GRADLE_VERSION}..."
  rm -f "$GRADLE_ZIP"
  curl -fL --retry 3 --connect-timeout 20 \
    "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" \
    -o "$GRADLE_ZIP"
  echo "Unpacking Gradle..."
  unzip -q -o "$GRADLE_ZIP" -d "$ROOT/.buildtools"
fi

echo
echo "Building GalaxyPad WebRTC APK..."
"$GRADLE_HOME/bin/gradle" --no-daemon clean assembleDebug

APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
OUT="$ROOT/GalaxyPad-WebRTC-debug.apk"
if [ ! -f "$APK" ]; then
  say_err "Gradle completed but app-debug.apk was not found."
  read -r -p "Press Enter to close..." _ || true
  exit 1
fi
cp -f "$APK" "$OUT"

echo
echo "SUCCESS"
echo "APK: $OUT"
echo
open -R "$OUT" 2>/dev/null || true
read -r -p "Press Enter to close..." _ || true
