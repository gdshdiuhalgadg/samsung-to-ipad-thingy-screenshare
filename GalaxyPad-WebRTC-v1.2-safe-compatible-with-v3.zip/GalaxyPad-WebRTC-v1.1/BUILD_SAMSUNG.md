# Build the Samsung APK

## Fastest: Android Studio

1. Install current Android Studio on Mac/Windows.
2. Open the `GalaxyPad-WebRTC-v1` folder.
3. Let Gradle sync. If asked, install Android SDK Platform 35.
4. Connect the Samsung by USB and enable Developer options + USB debugging.
5. Press **Run** to install directly, or use:

   **Build > Build App Bundle(s) / APK(s) > Build APK(s)**

6. Android Studio creates a debug APK under:

   `app/build/outputs/apk/debug/app-debug.apk`

No iPad build exists because the iPad side is a webpage served by the Samsung.

## Optional: GitHub Actions

This project includes `.github/workflows/build-apk.yml`.

1. Push the folder to a GitHub repository.
2. Open **Actions > Build Samsung APK**.
3. Run the workflow or push to `main`.
4. Download the `GalaxyPad-WebRTC-debug` artifact.

The workflow builds a debug APK. For long-term distribution you should create your own Android signing key and a signed release APK.
