# GalaxyPad WebRTC v1

A LAN-only, low-latency Samsung/Android screen sender with a **zero-install iPad receiver**.

## Build v1.1

This package now includes `BUILD_APK_MAC.command` and `BUILD_APK_WINDOWS.bat`. They download Gradle 8.10.2 automatically, use the Android SDK installed by Android Studio, run `assembleDebug`, and copy the result to `GalaxyPad-WebRTC-debug.apk` in the project root. Android SDK Platform 35 must be installed.

## What runs where

- **Samsung:** native Android app, because Android mobile browsers do not expose screen capture (`getDisplayMedia`) reliably.
- **iPad:** Safari only. No IPA, TestFlight, App Store install, or receiver app.
- **Server:** the Samsung phone itself. It serves the receiver webpage and WebSocket signaling on port **8080**.
- **Media path:** direct WebRTC peer-to-peer over the local Wi-Fi. There is no cloud media relay and no TURN server in this LAN build.

## How to use

1. Build and install the Android app (see `BUILD_SAMSUNG.md`).
2. Put Samsung and iPad on the same Wi-Fi / hotspot LAN.
3. Open **GalaxyPad WebRTC** on the Samsung.
4. Select:
   - `1080-class / 60 fps` first, or
   - `720-class / 120 fps` for the experimental minimum-latency mode.
5. Tap **START SCREEN STREAM** and approve Android's screen-capture prompt.
6. The Samsung app shows a URL such as:

   `http://192.168.1.23:8080/`

7. Open that URL in Safari on the iPad.
8. Tap **CONNECT**.
9. The video page shows received FPS, bitrate, packet loss, jitter, WebRTC jitter-buffer delay, average decode time, and network RTT.

## Important latency reality

This project is deliberately tuned to minimize buffering, but **20 ms glass-to-glass is an experimental best case, not a guaranteed operating point**.

- A 60 Hz display has a 16.7 ms frame interval by itself.
- WebRTC, H.264 encode/decode, Wi-Fi scheduling and two display pipelines all consume time.
- A realistic first target is roughly **30–60 ms** on good 60 Hz hardware.
- On 120 Hz Samsung + 120 Hz iPad Pro hardware, **~20–40 ms** is the aggressive target range.
- The 120 fps mode can be clamped by the Samsung compositor, libwebrtc, encoder hardware, thermal state or iPad decode/display path.

## Low-latency choices in this build

- Native Android `MediaProjection` via WebRTC `ScreenCapturerAndroid`.
- Texture path rather than CPU bitmap copies.
- Hardware-capable WebRTC encoder/decoder factories.
- H.264 is moved to the front of the video SDP codec list; other codecs remain as fallback.
- No STUN/TURN servers in the LAN configuration: host ICE candidates only.
- ICE TCP disabled; direct UDP candidate pairs are preferred by construction.
- `bundlePolicy = MAXBUNDLE`, `rtcpMuxPolicy = REQUIRE`, candidate pool = 0.
- Sender bitrate and frame-rate limits set directly on `RtpSender`.
- `MAINTAIN_FRAMERATE` degradation preference.
- Safari receiver is video-only, muted, `playsinline`, and has no application-level playback queue.
- Safari 27+ low-latency receiver controls are feature-detected and set to their minimum when available; older Safari continues without them.

## LAN/security scope

This is a personal/local-network prototype. The receiver page uses plain HTTP and WebSocket on the private LAN. WebRTC media itself uses the normal WebRTC DTLS/SRTP transport, but the tiny signaling endpoint in this prototype has **no authentication**. Do not expose TCP/8080 to the public internet.

## Files

- `app/` — Samsung Android application.
- `receiver-preview.html` — exact receiver UI for preview/debugging only. The actual receiver page is embedded in the Android app and served from the Samsung.
- `BUILD_SAMSUNG.md` — Android Studio and GitHub Actions build instructions.
- `LATENCY_TUNING.md` — test procedure and tuning priorities.
- `.github/workflows/build-apk.yml` — optional cloud build of a debug APK after pushing this folder to GitHub.


## v1.2 Safe connection patch
- Removes manual RtpSender encoding parameter changes during first peer creation.
- Removes SDP payload reordering during offer creation.
- Adds guarded peer setup and visible signalling error status.
- Intended to fix Samsung process crashes triggered when Safari connects.
