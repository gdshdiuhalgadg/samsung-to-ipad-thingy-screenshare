# Latency tuning and measurement

## First successful test

Start with `1080-class / 60 fps`.

Use:
- same Wi-Fi access point,
- preferably clean 5 GHz or 6 GHz,
- both devices close to the AP,
- battery saver off,
- Samsung display set to its high refresh-rate mode,
- iPad Low Power Mode off,
- no VPN on either device.

Once stable, test `720-class / 120 fps`.

## The iPad HUD

The receiver reports:
- received resolution and decoded FPS,
- Mbps,
- packets lost,
- RTP jitter,
- average WebRTC jitter-buffer delay,
- average decode time,
- network round-trip time.

These are useful pipeline/network metrics, but **they are not glass-to-glass latency**.

## Measure actual glass-to-glass delay

The simplest reliable method is a high-frame-rate external camera:

1. Put Samsung and iPad side-by-side.
2. Display a millisecond stopwatch or a fast-changing test counter on the Samsung.
3. Record both screens in one shot at 240 fps if possible.
4. Step through the footage frame-by-frame.
5. Count frames between the change on Samsung and the same change on iPad.

At 240 fps each camera frame is about 4.17 ms.

## What to optimize first

1. **Refresh rate:** 120 Hz on both ends helps enormously.
2. **Wi-Fi:** avoid congested 2.4 GHz and guest/client-isolated networks.
3. **Resolution:** 720-class/120 can beat 1080/60 for latency even though quality is lower.
4. **Thermals:** Samsung hardware encoding can throttle when hot.
5. **Receiver jitter buffer:** Safari 27+ exposes controls the page automatically attempts to minimize.
6. **Codec:** H.264 is preferred for Apple/Samsung hardware compatibility; WebRTC fallback codecs remain enabled if H.264 cannot negotiate.

## 20 ms target

Treat 20 ms as a laboratory target. A more useful product goal is **consistently below 40 ms** with no stutter or accumulating delay. Consistent 25–40 ms feels essentially immediate for screen mirroring.
