package com.krish.galaxypadwebrtc

import java.net.Inet4Address
import java.net.NetworkInterface

object LocalNet {
    fun ipv4Addresses(): List<String> {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }
                .filterIsInstance<Inet4Address>()
                .filter { !it.isLoopbackAddress && it.isSiteLocalAddress }
                .mapNotNull { it.hostAddress }
                .distinct()
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
