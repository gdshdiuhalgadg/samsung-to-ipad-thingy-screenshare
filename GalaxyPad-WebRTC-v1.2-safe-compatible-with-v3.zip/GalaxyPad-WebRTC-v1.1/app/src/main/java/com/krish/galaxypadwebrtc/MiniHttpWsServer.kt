package com.krish.galaxypadwebrtc

import android.util.Base64
import android.util.Log
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.EOFException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MiniHttpWsServer(
    private val port: Int,
    private val listener: Listener
) : Closeable {

    interface Listener {
        fun onOpen(client: WsClient)
        fun onText(client: WsClient, text: String)
        fun onClose(client: WsClient)
    }

    class WsClient internal constructor(private val socket: Socket) : Closeable {
        private val output = BufferedOutputStream(socket.getOutputStream())
        private val closed = AtomicBoolean(false)

        @Synchronized
        fun sendText(text: String) {
            if (closed.get()) return
            try {
                val payload = text.toByteArray(Charsets.UTF_8)
                val header = ArrayList<Byte>(14)
                header += 0x81.toByte()
                when {
                    payload.size <= 125 -> header += payload.size.toByte()
                    payload.size <= 0xFFFF -> {
                        header += 126.toByte()
                        header += ((payload.size ushr 8) and 0xFF).toByte()
                        header += (payload.size and 0xFF).toByte()
                    }
                    else -> {
                        header += 127.toByte()
                        val n = payload.size.toLong()
                        for (i in 7 downTo 0) header += ((n ushr (i * 8)) and 0xFF).toByte()
                    }
                }
                output.write(header.toByteArray())
                output.write(payload)
                output.flush()
            } catch (_: Throwable) {
                close()
            }
        }

        @Synchronized
        internal fun sendPong(payload: ByteArray) {
            if (closed.get()) return
            output.write(0x8A)
            output.write(payload.size)
            output.write(payload)
            output.flush()
        }

        override fun close() {
            if (closed.compareAndSet(false, true)) {
                try { socket.close() } catch (_: Throwable) {}
            }
        }
    }

    private val running = AtomicBoolean(false)
    private val pool = Executors.newCachedThreadPool()
    private var server: ServerSocket? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        val ss = ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(port))
        }
        server = ss
        pool.execute {
            while (running.get()) {
                try {
                    val socket = ss.accept().apply { tcpNoDelay = true }
                    pool.execute { handle(socket) }
                } catch (t: Throwable) {
                    if (running.get()) Log.w(TAG, "accept failed", t)
                }
            }
        }
    }

    private fun handle(socket: Socket) {
        val input = BufferedInputStream(socket.getInputStream())
        try {
            val raw = readHttpHeaders(input)
            val lines = raw.split("\r\n")
            val requestLine = lines.firstOrNull().orEmpty().split(' ')
            val path = requestLine.getOrNull(1) ?: "/"
            val headers = lines.drop(1).mapNotNull { line ->
                val p = line.indexOf(':')
                if (p <= 0) null else line.substring(0, p).trim().lowercase() to line.substring(p + 1).trim()
            }.toMap()

            val isWs = headers["upgrade"]?.equals("websocket", ignoreCase = true) == true
            if (path == "/ws" && isWs) {
                upgradeWebSocket(socket, input, headers)
            } else {
                serveHttp(socket, path)
            }
        } catch (_: Throwable) {
            try { socket.close() } catch (_: Throwable) {}
        }
    }

    private fun serveHttp(socket: Socket, path: String) {
        val body: ByteArray
        val contentType: String
        val code: String
        if (path == "/" || path.startsWith("/?")) {
            body = ReceiverPage.html.toByteArray(Charsets.UTF_8)
            contentType = "text/html; charset=utf-8"
            code = "200 OK"
        } else {
            body = "Not found".toByteArray()
            contentType = "text/plain; charset=utf-8"
            code = "404 Not Found"
        }

        val out = BufferedOutputStream(socket.getOutputStream())
        val headers = buildString {
            append("HTTP/1.1 $code\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: ${body.size}\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n\r\n")
        }.toByteArray(Charsets.US_ASCII)
        out.write(headers)
        out.write(body)
        out.flush()
        socket.close()
    }

    private fun upgradeWebSocket(socket: Socket, input: BufferedInputStream, headers: Map<String, String>) {
        val key = headers["sec-websocket-key"] ?: throw IllegalArgumentException("missing websocket key")
        val accept = Base64.encodeToString(
            MessageDigest.getInstance("SHA-1").digest((key + WS_GUID).toByteArray(Charsets.US_ASCII)),
            Base64.NO_WRAP
        )
        val out = BufferedOutputStream(socket.getOutputStream())
        out.write(
            ("HTTP/1.1 101 Switching Protocols\r\n" +
                "Upgrade: websocket\r\n" +
                "Connection: Upgrade\r\n" +
                "Sec-WebSocket-Accept: $accept\r\n\r\n").toByteArray(Charsets.US_ASCII)
        )
        out.flush()

        val client = WsClient(socket)
        listener.onOpen(client)
        try {
            while (running.get() && !socket.isClosed) {
                val b1 = input.read()
                if (b1 < 0) break
                val b2 = input.read()
                if (b2 < 0) break

                val opcode = b1 and 0x0F
                val masked = (b2 and 0x80) != 0
                var length = (b2 and 0x7F).toLong()
                if (length == 126L) {
                    length = ((input.read() and 0xFF) shl 8 or (input.read() and 0xFF)).toLong()
                } else if (length == 127L) {
                    length = 0
                    repeat(8) { length = (length shl 8) or (input.read() and 0xFF).toLong() }
                }
                if (length > MAX_WS_FRAME) throw IllegalArgumentException("frame too large")

                val mask = if (masked) readExactly(input, 4) else null
                val payload = readExactly(input, length.toInt())
                if (mask != null) {
                    for (i in payload.indices) payload[i] = (payload[i].toInt() xor mask[i and 3].toInt()).toByte()
                }

                when (opcode) {
                    0x1 -> listener.onText(client, payload.toString(Charsets.UTF_8))
                    0x8 -> break
                    0x9 -> client.sendPong(payload)
                }
            }
        } finally {
            listener.onClose(client)
            client.close()
        }
    }

    private fun readHttpHeaders(input: BufferedInputStream): String {
        val out = ArrayList<Byte>(2048)
        var state = 0
        while (out.size < MAX_HEADER) {
            val b = input.read()
            if (b < 0) throw EOFException()
            out += b.toByte()
            state = when {
                state == 0 && b == '\r'.code -> 1
                state == 1 && b == '\n'.code -> 2
                state == 2 && b == '\r'.code -> 3
                state == 3 && b == '\n'.code -> 4
                else -> 0
            }
            if (state == 4) return out.toByteArray().toString(Charsets.US_ASCII)
        }
        throw IllegalArgumentException("headers too large")
    }

    private fun readExactly(input: BufferedInputStream, count: Int): ByteArray {
        val data = ByteArray(count)
        var off = 0
        while (off < count) {
            val n = input.read(data, off, count - off)
            if (n <= 0) throw EOFException()
            off += n
        }
        return data
    }

    override fun close() {
        running.set(false)
        try { server?.close() } catch (_: Throwable) {}
        pool.shutdownNow()
    }

    companion object {
        private const val TAG = "GalaxyPadMiniServer"
        private const val WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        private const val MAX_HEADER = 32 * 1024
        private const val MAX_WS_FRAME = 2L * 1024L * 1024L
    }
}
