package com.krish.galaxypadwebrtc

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Point
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Display
import android.hardware.display.DisplayManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.roundToInt

class StreamService : Service(), MiniHttpWsServer.Listener {
    companion object {
        const val ACTION_START = "com.krish.galaxypadwebrtc.START"
        const val ACTION_STOP = "com.krish.galaxypadwebrtc.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_PROJECTION_DATA = "projectionData"
        const val EXTRA_MODE = "mode"
        const val PORT = 8080
        private const val CHANNEL_ID = "galaxypad_webrtc"
        private const val NOTIFICATION_ID = 81
        private const val TAG = "GalaxyPadWebRTC"
    }

    private var eglBase: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var surfaceHelper: SurfaceTextureHelper? = null
    private var capturer: ScreenCapturerAndroid? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var peer: PeerConnection? = null
    private var server: MiniHttpWsServer? = null
    private var activeClient: MiniHttpWsServer.WsClient? = null
    private val pendingRemoteCandidates = CopyOnWriteArrayList<IceCandidate>()
    @Volatile private var remoteDescriptionReady = false

    private var captureWidth = 1280
    private var captureHeight = 720
    private var captureFps = 60
    private var maxBitrate = 12_000_000

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopEverything()
            ACTION_START -> {
                startAsForeground()
                try {
                    startEverything(intent)
                } catch (t: Throwable) {
                    Log.e(TAG, "start failed", t)
                    stopEverything()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startEverything(intent: Intent) {
        releaseStreamingObjects()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val projectionData: Intent = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
        } ?: error("Missing MediaProjection data")
        require(resultCode == Activity.RESULT_OK) { "Screen capture was not approved" }

        val mode = intent.getIntExtra(EXTRA_MODE, 0)
        chooseCaptureFormat(mode)
        initWebRtc()
        startScreenCapture(projectionData)

        server = MiniHttpWsServer(PORT, this).also { it.start() }
        Log.i(TAG, "Receiver web page ready on port $PORT; capture=${captureWidth}x$captureHeight@$captureFps")
    }

    private fun chooseCaptureFormat(mode: Int) {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        @Suppress("DEPRECATION")
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point()
        val m = display?.mode
        if (m != null) {
            p.x = m.physicalWidth
            p.y = m.physicalHeight
        } else {
            p.x = resources.displayMetrics.widthPixels
            p.y = resources.displayMetrics.heightPixels
        }

        val longTarget = if (mode == 1) 1280 else 1920
        val sourceLong = maxOf(p.x, p.y).toFloat().coerceAtLeast(1f)
        val scale = minOf(1f, longTarget / sourceLong)
        captureWidth = (((p.x * scale).roundToInt().coerceAtLeast(320)) / 2) * 2
        captureHeight = (((p.y * scale).roundToInt().coerceAtLeast(320)) / 2) * 2
        captureFps = if (mode == 1) 120 else 60
        maxBitrate = if (mode == 1) 14_000_000 else 16_000_000
    }

    private fun initWebRtc() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )

        eglBase = EglBase.create()
        val encoderFactory = DefaultVideoEncoderFactory(eglBase!!.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        videoSource = factory!!.createVideoSource(true)
        videoTrack = factory!!.createVideoTrack("screen0", videoSource!!).apply { setEnabled(true) }
    }

    private fun startScreenCapture(projectionData: Intent) {
        surfaceHelper = SurfaceTextureHelper.create("GalaxyPadCapture", eglBase!!.eglBaseContext)
        capturer = ScreenCapturerAndroid(projectionData, object : android.media.projection.MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "MediaProjection stopped by system/user")
                stopEverything()
            }
        })
        capturer!!.initialize(surfaceHelper!!, applicationContext, videoSource!!.capturerObserver)
        capturer!!.startCapture(captureWidth, captureHeight, captureFps)
    }

    override fun onOpen(client: MiniHttpWsServer.WsClient) {
        Log.i(TAG, "iPad signaling socket connected")
        activeClient?.takeIf { it !== client }?.close()
        activeClient = client
        try {
            createPeerAndOffer(client)
        } catch (t: Throwable) {
            Log.e(TAG, "peer setup failed", t)
            client.sendText(
                JSONObject()
                    .put("type", "status")
                    .put("text", "Sender setup error: ${t.javaClass.simpleName}: ${t.message ?: "unknown"}")
                    .toString()
            )
            closePeer()
        }
    }

    override fun onText(client: MiniHttpWsServer.WsClient, text: String) {
        if (client !== activeClient) return
        try {
            val msg = JSONObject(text)
            when (msg.optString("type")) {
                "answer" -> {
                    val sdp = msg.getString("sdp")
                    remoteDescriptionReady = false
                    peer?.setRemoteDescription(object : SdpObserverAdapter() {
                        override fun onSetSuccess() {
                            remoteDescriptionReady = true
                            pendingRemoteCandidates.forEach { peer?.addIceCandidate(it) }
                            pendingRemoteCandidates.clear()
                            client.sendText(JSONObject().put("type", "status").put("text", "WebRTC connected; waiting for first frame…").toString())
                        }
                        override fun onSetFailure(error: String?) {
                            Log.e(TAG, "remote answer failed: $error")
                            client.sendText(JSONObject().put("type", "status").put("text", "Remote SDP error: ${error ?: "unknown"}").toString())
                        }
                    }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
                }
                "candidate" -> {
                    val c = IceCandidate(
                        msg.optString("sdpMid", "0"),
                        msg.optInt("sdpMLineIndex", 0),
                        msg.getString("candidate")
                    )
                    if (remoteDescriptionReady) peer?.addIceCandidate(c) else pendingRemoteCandidates += c
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "bad signaling message", t)
        }
    }

    override fun onClose(client: MiniHttpWsServer.WsClient) {
        if (client === activeClient) {
            activeClient = null
            closePeer()
        }
    }

    /**
     * Conservative peer setup for Samsung devices.
     *
     * v1.1 modified RtpSender encoding parameters and rewrote the SDP before
     * setLocalDescription(). Some Android hardware/libwebrtc combinations can
     * become unstable at that point. For the first stable connection we let
     * libwebrtc choose its supported codec/encoder parameters itself.
     */
    @Synchronized
    private fun createPeerAndOffer(client: MiniHttpWsServer.WsClient) {
        closePeer()
        remoteDescriptionReady = false
        pendingRemoteCandidates.clear()

        val config = PeerConnection.RTCConfiguration(emptyList<PeerConnection.IceServer>()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            iceCandidatePoolSize = 0
        }

        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(newState: PeerConnection.SignalingState) = Unit
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) {
                Log.i(TAG, "ICE $newState")
            }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
                Log.i(TAG, "Peer $newState")
                client.sendText(JSONObject().put("type", "status").put("text", "Peer: $newState").toString())
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState) = Unit
            override fun onIceCandidate(candidate: IceCandidate) {
                if (client !== activeClient) return
                client.sendText(
                    JSONObject()
                        .put("type", "candidate")
                        .put("candidate", candidate.sdp)
                        .put("sdpMid", candidate.sdpMid)
                        .put("sdpMLineIndex", candidate.sdpMLineIndex)
                        .toString()
                )
            }
            override fun onIceCandidatesRemoved(candidates: Array<IceCandidate>) = Unit
            override fun onAddStream(stream: MediaStream) = Unit
            override fun onRemoveStream(stream: MediaStream) = Unit
            override fun onDataChannel(dataChannel: DataChannel) = Unit
            override fun onRenegotiationNeeded() = Unit
        }

        val pc = factory?.createPeerConnection(config, observer)
            ?: throw IllegalStateException("Unable to create PeerConnection")
        peer = pc

        val track = videoTrack ?: throw IllegalStateException("Screen video track is not ready")
        pc.addTrack(track, listOf("screen"))
            ?: throw IllegalStateException("Unable to add screen track")

        pc.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc == null || client !== activeClient) return
                pc.setLocalDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        client.sendText(
                            JSONObject()
                                .put("type", "offer")
                                .put("sdp", desc.description)
                                .toString()
                        )
                    }
                    override fun onSetFailure(error: String?) {
                        Log.e(TAG, "setLocalDescription failed: $error")
                        client.sendText(JSONObject().put("type", "status").put("text", "Local SDP error: ${error ?: "unknown"}").toString())
                    }
                }, desc)
            }
            override fun onCreateFailure(error: String?) {
                Log.e(TAG, "createOffer failed: $error")
                client.sendText(JSONObject().put("type", "status").put("text", "Offer error: ${error ?: "unknown"}").toString())
            }
        }, MediaConstraints())
    }

    private fun closePeer() {
        remoteDescriptionReady = false
        pendingRemoteCandidates.clear()
        try { peer?.close() } catch (_: Throwable) {}
        peer = null
    }

    private fun releaseStreamingObjects() {
        try { server?.close() } catch (_: Throwable) {}
        server = null
        try { activeClient?.close() } catch (_: Throwable) {}
        activeClient = null
        closePeer()
        try { capturer?.stopCapture() } catch (_: Throwable) {}
        try { capturer?.dispose() } catch (_: Throwable) {}
        capturer = null
        try { surfaceHelper?.dispose() } catch (_: Throwable) {}
        surfaceHelper = null
        try { videoTrack?.dispose() } catch (_: Throwable) {}
        videoTrack = null
        try { videoSource?.dispose() } catch (_: Throwable) {}
        videoSource = null
        try { factory?.dispose() } catch (_: Throwable) {}
        factory = null
        try { eglBase?.release() } catch (_: Throwable) {}
        eglBase = null
    }

    private fun stopEverything() {
        releaseStreamingObjects()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        stopSelf()
    }

    override fun onDestroy() {
        releaseStreamingObjects()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("GalaxyPad WebRTC is sharing your screen")
            .setContentText("Direct low-latency stream to iPad Safari")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Screen streaming", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
