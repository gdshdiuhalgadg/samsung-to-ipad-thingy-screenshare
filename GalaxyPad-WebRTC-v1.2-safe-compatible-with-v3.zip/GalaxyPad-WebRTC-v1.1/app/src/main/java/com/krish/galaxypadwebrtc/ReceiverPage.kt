package com.krish.galaxypadwebrtc

object ReceiverPage {
    val html = """
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="theme-color" content="#000000">
<title>GalaxyPad Live</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; width: 100%; height: 100%; background: #000; overflow: hidden; font-family: -apple-system, BlinkMacSystemFont, system-ui, sans-serif; }
  #video { position: fixed; inset: 0; width: 100%; height: 100%; object-fit: contain; background: #000; }
  #hud { position: fixed; top: max(12px, env(safe-area-inset-top)); left: max(12px, env(safe-area-inset-left)); right: max(12px, env(safe-area-inset-right)); display: flex; justify-content: space-between; align-items: flex-start; pointer-events: none; }
  .panel { background: rgba(0,0,0,.56); border: 1px solid rgba(255,255,255,.18); border-radius: 14px; padding: 10px 12px; backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px); }
  #title { font-weight: 700; font-size: 15px; }
  #stats { font-variant-numeric: tabular-nums; font-size: 12px; line-height: 1.45; opacity: .9; margin-top: 4px; white-space: pre-line; }
  #controls { position: fixed; left: 50%; bottom: max(22px, env(safe-area-inset-bottom)); transform: translateX(-50%); display: flex; gap: 10px; }
  button { border: 0; border-radius: 999px; padding: 13px 18px; font-weight: 700; font-size: 16px; color: #fff; background: rgba(40,40,40,.88); box-shadow: 0 4px 22px rgba(0,0,0,.4); }
  button.primary { background: #0a84ff; }
  button:disabled { opacity: .45; }
  #badge { display:inline-block; width:8px; height:8px; border-radius:50%; background:#ff453a; margin-right:7px; }
  #tip { position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%); max-width: 85vw; text-align:center; color:#ddd; font-size:16px; line-height:1.4; pointer-events:none; }
  .hidden { display:none !important; }
</style>
</head>
<body>
<video id="video" autoplay muted playsinline disablepictureinpicture></video>
<div id="hud">
  <div class="panel">
    <div id="title"><span id="badge"></span><span id="state">Ready</span></div>
    <div id="stats">Tap CONNECT</div>
  </div>
</div>
<div id="tip">Samsung and iPad must be on the same Wi‑Fi.<br>Tap CONNECT to start the direct WebRTC stream.</div>
<div id="controls">
  <button id="connect" class="primary">CONNECT</button>
  <button id="fullscreen">FULL SCREEN</button>
</div>
<script>
(() => {
  'use strict';
  const video = document.getElementById('video');
  const connectBtn = document.getElementById('connect');
  const fullscreenBtn = document.getElementById('fullscreen');
  const stateEl = document.getElementById('state');
  const statsEl = document.getElementById('stats');
  const badge = document.getElementById('badge');
  const tip = document.getElementById('tip');
  let ws = null;
  let pc = null;
  let statsTimer = null;
  let lastBytes = 0;
  let lastTs = 0;
  let remoteReady = false;
  let pendingCandidates = [];

  function setState(text, ok=false) {
    stateEl.textContent = text;
    badge.style.background = ok ? '#30d158' : '#ff9f0a';
  }

  async function makePeer() {
    if (pc) { try { pc.close(); } catch(_) {} }
    pc = new RTCPeerConnection({
      iceServers: [],
      bundlePolicy: 'max-bundle',
      rtcpMuxPolicy: 'require',
      iceCandidatePoolSize: 0
    });

    remoteReady = false;
    pendingCandidates = [];

    pc.ontrack = async (ev) => {
      // Safari 27+ exposes explicit receiver-latency controls. Feature-detect them.
      try {
        if ('jitterBufferTarget' in ev.receiver) ev.receiver.jitterBufferTarget = 0;
        if ('playoutDelayHint' in ev.receiver) ev.receiver.playoutDelayHint = 0;
      } catch (_) {}
      const stream = ev.streams && ev.streams[0] ? ev.streams[0] : new MediaStream([ev.track]);
      video.srcObject = stream;
      tip.classList.add('hidden');
      try { await video.play(); } catch (_) {}
      setState('LIVE', true);
      startStats();
    };

    pc.onicecandidate = (ev) => {
      if (!ev.candidate || !ws || ws.readyState !== WebSocket.OPEN) return;
      ws.send(JSON.stringify({
        type: 'candidate',
        candidate: ev.candidate.candidate,
        sdpMid: ev.candidate.sdpMid,
        sdpMLineIndex: ev.candidate.sdpMLineIndex
      }));
    };

    pc.onconnectionstatechange = () => {
      const s = pc.connectionState;
      if (s === 'connected') setState('LIVE', true);
      else if (s === 'failed' || s === 'disconnected' || s === 'closed') setState(s.toUpperCase(), false);
      else setState(s.toUpperCase(), false);
    };
  }

  async function connect() {
    connectBtn.disabled = true;
    setState('CONNECTING');
    statsEl.textContent = 'Direct LAN WebRTC';
    await makePeer();

    const scheme = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(`§{scheme}://§{location.host}/ws`);

    ws.onopen = () => setState('NEGOTIATING');
    ws.onerror = () => {
      setState('SIGNAL ERROR');
      connectBtn.disabled = false;
    };
    ws.onclose = () => {
      if (!pc || pc.connectionState !== 'connected') setState('DISCONNECTED');
      connectBtn.disabled = false;
    };

    ws.onmessage = async (ev) => {
      const msg = JSON.parse(ev.data);
      try {
        if (msg.type === 'offer') {
          await pc.setRemoteDescription({ type: 'offer', sdp: msg.sdp });
          remoteReady = true;
          for (const c of pendingCandidates.splice(0)) await pc.addIceCandidate(c);
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          ws.send(JSON.stringify({ type: 'answer', sdp: pc.localDescription.sdp }));
        } else if (msg.type === 'candidate' && msg.candidate) {
          const c = { candidate: msg.candidate, sdpMid: msg.sdpMid, sdpMLineIndex: msg.sdpMLineIndex };
          if (remoteReady) await pc.addIceCandidate(c); else pendingCandidates.push(c);
        } else if (msg.type === 'status') {
          statsEl.textContent = msg.text || '';
        }
      } catch (e) {
        console.error(e);
        setState('NEGOTIATION ERROR');
        statsEl.textContent = String(e);
      }
    };
  }

  function startStats() {
    clearInterval(statsTimer);
    lastBytes = 0; lastTs = 0;
    statsTimer = setInterval(async () => {
      if (!pc) return;
      const report = await pc.getStats();
      let inbound = null, pair = null;
      report.forEach(r => {
        if (r.type === 'inbound-rtp' && r.kind === 'video') inbound = r;
        if (r.type === 'candidate-pair' && r.state === 'succeeded' && (r.nominated || r.selected)) pair = r;
      });
      if (!inbound) return;

      const now = inbound.timestamp || performance.now();
      const bytes = inbound.bytesReceived || 0;
      let mbps = 0;
      if (lastTs && now > lastTs) mbps = ((bytes - lastBytes) * 8 / 1e6) / ((now - lastTs) / 1000);
      lastBytes = bytes; lastTs = now;

      const fps = inbound.framesPerSecond || 0;
      const w = inbound.frameWidth || video.videoWidth || 0;
      const h = inbound.frameHeight || video.videoHeight || 0;
      const lost = inbound.packetsLost || 0;
      const jitterMs = (inbound.jitter || 0) * 1000;
      const avgJbMs = inbound.jitterBufferEmittedCount
        ? (inbound.jitterBufferDelay / inbound.jitterBufferEmittedCount) * 1000 : 0;
      const decodeMs = inbound.framesDecoded
        ? (inbound.totalDecodeTime / inbound.framesDecoded) * 1000 : 0;
      const rttMs = pair && pair.currentRoundTripTime != null ? pair.currentRoundTripTime * 1000 : 0;

      statsEl.textContent =
        `§{w}×§{h}  §{fps.toFixed(0)} fps\n` +
        `§{mbps.toFixed(1)} Mbps  lost §{lost}\n` +
        `jitter §{jitterMs.toFixed(1)} ms  buffer §{avgJbMs.toFixed(1)} ms\n` +
        `decode §{decodeMs.toFixed(1)} ms  RTT §{rttMs.toFixed(1)} ms`;
    }, 1000);
  }

  connectBtn.addEventListener('click', connect);
  fullscreenBtn.addEventListener('click', async () => {
    try {
      if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
      else if (video.webkitEnterFullscreen) video.webkitEnterFullscreen();
    } catch (_) {}
  });

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && video.srcObject) video.play().catch(() => {});
  });
})();
</script>
</body>
</html>
""".trimIndent().replace("§", "\$")
}
