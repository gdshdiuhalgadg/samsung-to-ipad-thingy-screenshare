$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$Root = $PSScriptRoot
$GradleVersion = "8.10.2"
$Tools = Join-Path $Root ".buildtools"
$GradleZip = Join-Path $Tools "gradle-$GradleVersion-bin.zip"
$GradleHome = Join-Path $Tools "gradle-$GradleVersion"

function Fail([string]$Message) {
  Write-Host ""
  Write-Host "ERROR: $Message" -ForegroundColor Red
  Write-Host ""
  Read-Host "Press Enter to close"
  exit 1
}

$Sdk = $env:ANDROID_SDK_ROOT
if (-not $Sdk) { $Sdk = $env:ANDROID_HOME }
if (-not $Sdk) {
  $candidate = Join-Path $env:LOCALAPPDATA "Android\Sdk"
  if (Test-Path $candidate) { $Sdk = $candidate }
}
if (-not $Sdk -or -not (Test-Path $Sdk)) {
  Fail "Android SDK not found. Open Android Studio > Settings > Android SDK and install Android SDK Platform 35."
}
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk

if (-not (Test-Path (Join-Path $Sdk "platforms\android-35\android.jar"))) {
  Fail "Android SDK Platform 35 is not installed. In Android Studio: Settings > Android SDK > check Android 15 / API 35 > Apply."
}

$StudioJbr = Join-Path $env:ProgramFiles "Android\Android Studio\jbr"
if (Test-Path (Join-Path $StudioJbr "bin\java.exe")) {
  $env:JAVA_HOME = $StudioJbr
  $env:Path = "$StudioJbr\bin;$env:Path"
}

New-Item -ItemType Directory -Force -Path $Tools | Out-Null
$GradleExe = Join-Path $GradleHome "bin\gradle.bat"
if (-not (Test-Path $GradleExe)) {
  Write-Host "Downloading Gradle $GradleVersion..."
  if (Test-Path $GradleZip) { Remove-Item $GradleZip -Force }
  Invoke-WebRequest -UseBasicParsing -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $GradleZip
  Write-Host "Unpacking Gradle..."
  Expand-Archive -Path $GradleZip -DestinationPath $Tools -Force
}

Write-Host ""
Write-Host "Building GalaxyPad WebRTC APK..."
& $GradleExe --no-daemon clean assembleDebug
if ($LASTEXITCODE -ne 0) { Fail "Gradle build failed. Scroll up to the first red/error line." }

$Apk = Join-Path $Root "app\build\outputs\apk\debug\app-debug.apk"
$Out = Join-Path $Root "GalaxyPad-WebRTC-debug.apk"
if (-not (Test-Path $Apk)) { Fail "Gradle completed but app-debug.apk was not found." }
Copy-Item $Apk $Out -Force
Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "APK: $Out"
Start-Process explorer.exe "/select,`"$Out`""
Read-Host "Press Enter to close"
