package com.krish.galaxypadwebrtc

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var statusView: TextView
    private lateinit var urlView: TextView
    private lateinit var modeSpinner: Spinner

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            statusView.text = "Screen capture permission was not granted."
            return@registerForActivityResult
        }

        val serviceIntent = Intent(this, StreamService::class.java).apply {
            action = StreamService.ACTION_START
            putExtra(StreamService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(StreamService.EXTRA_PROJECTION_DATA, result.data)
            putExtra(StreamService.EXTRA_MODE, modeSpinner.selectedItemPosition)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        statusView.text = "Starting WebRTC sender… Open the address above on the iPad, then tap CONNECT."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val dp = resources.displayMetrics.density
        fun d(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(d(20), d(20), d(20), d(20))
        }

        root.addView(TextView(this).apply {
            text = "Galaxy → iPad WebRTC"
            textSize = 26f
        })

        root.addView(TextView(this).apply {
            text = "Ultra-low-latency LAN screen streaming. The iPad needs Safari only."
            textSize = 15f
            setPadding(0, d(10), 0, d(12))
        })

        urlView = TextView(this).apply {
            textSize = 20f
            setTextIsSelectable(true)
            movementMethod = LinkMovementMethod.getInstance()
            text = receiverUrls()
            setPadding(0, d(12), 0, d(16))
        }
        root.addView(urlView)

        modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf(
                    "1080-class / 60 fps — stable low latency",
                    "720-class / 120 fps — experimental minimum latency"
                )
            )
        }
        root.addView(modeSpinner)

        root.addView(Button(this).apply {
            text = "START SCREEN STREAM"
            setOnClickListener {
                requestNotificationPermissionIfNeeded()
                projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
            }
        })

        root.addView(Button(this).apply {
            text = "STOP STREAM"
            setOnClickListener {
                startService(Intent(this@MainActivity, StreamService::class.java).apply {
                    action = StreamService.ACTION_STOP
                })
                statusView.text = "Stopped."
            }
        })

        root.addView(Button(this).apply {
            text = "REFRESH IP ADDRESS"
            setOnClickListener { urlView.text = receiverUrls() }
        })

        statusView = TextView(this).apply {
            text = "1. Keep Samsung and iPad on the same Wi‑Fi.\n2. Tap START.\n3. On iPad open the URL above in Safari.\n4. Tap CONNECT."
            textSize = 15f
            setPadding(0, d(18), 0, 0)
        }
        root.addView(statusView)

        setContentView(root)
    }

    private fun receiverUrls(): String {
        val ips = LocalNet.ipv4Addresses()
        return if (ips.isEmpty()) {
            "Receiver URL appears here after Wi‑Fi is connected."
        } else {
            "Open on iPad:\n" + ips.joinToString("\n") { "http://$it:${StreamService.PORT}/" }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }
}
